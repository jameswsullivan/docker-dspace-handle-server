package net.cnri.util;

/** Exception that can be thrown when merging data with a template
 * @see Template
 */
public class TemplateException extends java.lang.Exception {

    public TemplateException(String str) {
        super(str);
    }

    public TemplateException() {
        super();
    }
}
