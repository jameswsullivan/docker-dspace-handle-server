package net.cnri.util;

/** Interface implemented by objects that can clone themselves as well as
 * all of the objects contained within them (as long as they also implement
 * the DeepClone interface).
 */
public interface DeepClone {

    public Object deepClone();

}
