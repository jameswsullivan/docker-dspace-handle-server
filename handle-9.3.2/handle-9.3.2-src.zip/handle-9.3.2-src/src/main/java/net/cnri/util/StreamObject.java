package net.cnri.util;

import java.io.*;

/** Interface for objects that can be read/written to and from streams.
 */
public interface StreamObject {

    public boolean isStreamTable();

    public boolean isStreamVector();

    public void readFrom(String str) throws StringEncodingException, IOException;

    public void readFrom(Reader str) throws StringEncodingException, IOException;

    public void readTheRest(Reader str) throws StringEncodingException, IOException;

    public String writeToString();

    public void writeTo(Writer out) throws IOException;

    public void writeTo(Writer out, int indentLevel) throws IOException;
}
