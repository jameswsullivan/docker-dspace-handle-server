package net.cnri.util;

/** Exception that may be thrown when parsing a StreamTable or StreamVector.
 */
public class StringEncodingException extends Exception {
    public StringEncodingException() {
        super();
    }

    public StringEncodingException(String s) {
        super(s);
    }
}
