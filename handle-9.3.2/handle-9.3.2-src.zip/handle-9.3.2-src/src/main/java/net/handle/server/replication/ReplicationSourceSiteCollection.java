package net.handle.server.replication;

import java.io.IOException;
import java.util.List;

import net.handle.hdllib.HandleException;

public interface ReplicationSourceSiteCollection {
    List<ReplicationSourceSiteInfo> getReplicationSourceSites();

    String getOwnName();

    void refresh() throws IOException, HandleException;
}
