package net.handle.hdllib;

public class GetSiteInfoResponse extends AbstractResponse {
    public SiteInfo siteInfo;

    /**************************************************************
     * Constructor used on the client side.
     **************************************************************/
    public GetSiteInfoResponse(SiteInfo siteInfo) {
        super(AbstractMessage.OC_GET_SITE_INFO, AbstractMessage.RC_SUCCESS);
        this.siteInfo = siteInfo;
    }

    /**************************************************************
     * Constructor used on the server side.
     **************************************************************/
    public GetSiteInfoResponse(AbstractRequest req, SiteInfo siteInfo) throws HandleException {
        super(req, AbstractMessage.RC_SUCCESS);
        this.siteInfo = siteInfo;
    }

    @Override
    public String toString() {
        return super.toString() + "; siteInfo:" + String.valueOf(siteInfo);
    }
}
