package net.handle.hdllib;

public class CreateHandleResponse extends AbstractResponse {

    // may be null if the server does not return the created handle
    public byte handle[];

    public CreateHandleResponse(byte handle[]) {
        super(OC_CREATE_HANDLE, AbstractMessage.RC_SUCCESS);
        this.handle = handle;
    }

    public CreateHandleResponse(AbstractRequest req, byte handle[]) throws HandleException {
        super(req, AbstractMessage.RC_SUCCESS);
        this.handle = handle;
    }
}
