package net.handle.util;

/**
 * @deprecated Replaced by net.cnri.util.StreamUtil
 */
@Deprecated
public class StringEncodingException extends Exception {
    public StringEncodingException() {
        super();
    }

    public StringEncodingException(String s) {
        super(s);
    }
}
