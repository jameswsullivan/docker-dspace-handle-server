package net.handle.hdllib;

/***********************************************************************
 * Interface for the transaction queue scanner that is used as a
 * callback from messages like DumpHandlesRequest.
 ***********************************************************************/

public interface TransactionScannerInterface {
    public Transaction nextTransaction() throws Exception;

    public void close();
}
