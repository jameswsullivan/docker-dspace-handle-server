package net.handle.hdllib;

/**
 * Request used to resolve a handle.  Holds the handle and parameters
 * used in resolution.
 */
public class ResolutionRequest extends AbstractRequest {

    public byte requestedTypes[][] = null;
    public int requestedIndexes[] = null;

    public ResolutionRequest(byte handle[], byte reqTypes[][], int reqIndexes[], AuthenticationInfo authInfo) {
        super(handle, AbstractMessage.OC_RESOLUTION, authInfo);
        this.requestedIndexes = reqIndexes;
        this.requestedTypes = reqTypes;
        this.authInfo = authInfo;
    }

    private String getTypesString() {
        if (requestedTypes == null || requestedTypes.length <= 0) return "[ ]";
        StringBuffer sb = new StringBuffer("[");
        for (byte[] requestedType : requestedTypes) {
            sb.append(Util.decodeString(requestedType));
            sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    private String getIndexesString() {
        if (requestedIndexes == null || requestedIndexes.length <= 0) return "[ ]";
        StringBuffer sb = new StringBuffer("[");
        for (int requestedIndexe : requestedIndexes) {
            sb.append(requestedIndexe);
            sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    @Override
    public String toString() {
        return super.toString() + ' ' + getTypesString() + ' ' + getIndexesString();
    }

}
