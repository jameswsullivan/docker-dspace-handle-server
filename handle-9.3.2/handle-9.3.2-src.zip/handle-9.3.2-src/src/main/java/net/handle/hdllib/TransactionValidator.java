package net.handle.hdllib;

import com.google.gson.JsonObject;

public interface TransactionValidator {

    boolean valid(Transaction txn) throws HandleException;

    default ValidationResult validate(Transaction txn) throws HandleException {
        if (valid(txn)) return new ValidationResult(true, null, null);
        else return new ValidationResult(false, null, null);
    }

    public static class ValidationResult {
        private final boolean isValid;
        private final String message;
        private final JsonObject report;

        public ValidationResult(boolean isValid, String message, JsonObject report) {
            this.isValid = isValid;
            this.message = message;
            this.report = report;
        }

        public boolean isValid() {
            return isValid;
        }

        public String getMessage() {
            return message;
        }

        public JsonObject getReport() {
            return report;
        }
    }
}
