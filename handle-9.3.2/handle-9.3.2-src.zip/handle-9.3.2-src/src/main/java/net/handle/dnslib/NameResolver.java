package net.handle.dnslib;

public interface NameResolver {
    void setCache(int prefetcherThreads, int size);

    Message respondToQuery(Message query);
}
