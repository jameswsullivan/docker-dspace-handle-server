package net.handle.hdllib;

import java.net.Socket;
import javax.crypto.SecretKey;

public class Session {

    public Socket socket;
    public SecretKey secretKey = null;
    public ServerInfo server;
}
