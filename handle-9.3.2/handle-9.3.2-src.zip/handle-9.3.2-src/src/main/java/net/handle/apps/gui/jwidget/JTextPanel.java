package net.handle.apps.gui.jwidget;

import net.handle.awt.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;

public class JTextPanel extends JPanel {

    public JTextPanel(String text) {
        super(new GridBagLayout());

        StringTokenizer tokenizer = new StringTokenizer(text, "\n");
        int currentRow = 0;
        add(new JLabel(""), AwtUtil.getConstraints(0, currentRow, 1, 1, 1, 1, true, true));
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            add(new JLabel(token, SwingConstants.LEFT), AwtUtil.getConstraints(1, currentRow++, 0, 0, 1, 1, true, false));
        }
        add(new Label(" "), AwtUtil.getConstraints(2, currentRow++, 1, 1, 1, 1, true, true));

    }

}
