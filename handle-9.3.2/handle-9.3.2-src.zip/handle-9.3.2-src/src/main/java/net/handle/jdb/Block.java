package net.handle.jdb;

abstract class Block {
    byte key[] = null, data[] = null;

    long thisRecord = 0, // File offset
        lastTouched = 0; // Holds system representation of a time
}
