package net.handle.hdllib.trust;

import net.handle.hdllib.HandleException;

public class TrustException extends HandleException {

    public TrustException(String message) {
        super(HandleException.SECURITY_ALERT, message);
    }

    public TrustException(String message, Throwable cause) {
        super(HandleException.SECURITY_ALERT, message, cause);
    }

}
