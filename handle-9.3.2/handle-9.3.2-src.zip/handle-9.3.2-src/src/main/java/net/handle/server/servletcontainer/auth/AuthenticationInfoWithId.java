package net.handle.server.servletcontainer.auth;

import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.Util;

public class AuthenticationInfoWithId {
    private final String id;
    private final AuthenticationInfo authInfo;

    public AuthenticationInfoWithId(AuthenticationInfo authInfo) {
        this(authInfo.getUserIdIndex() + ":" + Util.decodeString(authInfo.getUserIdHandle()), authInfo);
    }

    public AuthenticationInfoWithId(String id, AuthenticationInfo authInfo) {
        this.id = id;
        this.authInfo = authInfo;
    }

    public String getId() {
        return id;
    }

    public AuthenticationInfo getAuthInfo() {
        return authInfo;
    }
}
