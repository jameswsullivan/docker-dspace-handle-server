package net.handle.hdllib;

public class NextTxnIdResponse extends AbstractResponse {
    public long nextTxnId;

    public NextTxnIdResponse(long nextTxnId) {
        super(AbstractMessage.OC_GET_NEXT_TXN_ID, AbstractMessage.RC_SUCCESS);
        this.nextTxnId = nextTxnId;
    }

    public NextTxnIdResponse(AbstractRequest req, long nextTxnId) throws HandleException {
        super(req, AbstractMessage.RC_SUCCESS);
        this.nextTxnId = nextTxnId;
    }
}
