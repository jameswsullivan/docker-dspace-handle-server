package net.handle.util;

/**
 * @deprecated Replaced by net.cnri.util.TemplateException
 */
@Deprecated
public class TemplateException extends net.cnri.util.TemplateException {
    public TemplateException(String str) {
        super(str);
    }

    public TemplateException() {
        super();
    }
}
