package net.handle.server.replication;

import net.handle.hdllib.HandleException;

public interface NotifierInterface {
    public void sendNotification(String message) throws HandleException;

    public void sendNotification(String message, String type) throws HandleException;
}
