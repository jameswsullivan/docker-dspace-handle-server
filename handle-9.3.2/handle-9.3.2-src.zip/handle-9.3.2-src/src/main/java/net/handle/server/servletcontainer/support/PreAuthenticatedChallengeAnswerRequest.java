package net.handle.server.servletcontainer.support;

import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.ChallengeAnswerRequest;

public class PreAuthenticatedChallengeAnswerRequest extends ChallengeAnswerRequest {
    public PreAuthenticatedChallengeAnswerRequest(AuthenticationInfo authInfo) {
        super(authInfo.getAuthType(), authInfo.getUserIdHandle(), authInfo.getUserIdIndex(), null, authInfo);
    }
}
