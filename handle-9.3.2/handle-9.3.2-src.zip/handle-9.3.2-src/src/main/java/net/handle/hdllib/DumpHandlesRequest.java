package net.handle.hdllib;

/***************************************************************************
 * Request used to retrieve all handles from a server.  This
 * request is used for server&lt;-&gt;server (or replicator&lt;-&gt;server)
 * communication.
 ***************************************************************************/

public class DumpHandlesRequest extends AbstractRequest {

    public static final int HANDLE_REPLICATION_DB = 0;
    public static final int NA_REPLICATION_DB = 1;
    public static final int HANDLE = 2;
    public static final int NA = 3;

    // to specify which handles to send (filtered by how the handles are hashed)
    public int serverNum;
    public byte rcvrHashType;
    public int numServers;
    public byte[] startingPoint = null; //Optional handle used to resume the dump from a particular point.
    public int startingPointType;

    public DumpHandlesRequest(byte rcvrHashType, int numServers, int serverNum, AuthenticationInfo authInfo) {
        super(Common.BLANK_HANDLE, OC_DUMP_HANDLES, authInfo);
        this.rcvrHashType = rcvrHashType;
        this.numServers = numServers;
        this.serverNum = serverNum;
        this.certify = true;
        this.isAdminRequest = true;
        this.streaming = true;
    }

    public DumpHandlesRequest(byte rcvrHashType, int numServers, int serverNum, AuthenticationInfo authInfo, byte[] startingPoint, int startingPointType) {
        this(rcvrHashType, numServers, serverNum, authInfo);
        this.startingPoint = startingPoint;
        this.startingPointType = startingPointType;
    }
}
