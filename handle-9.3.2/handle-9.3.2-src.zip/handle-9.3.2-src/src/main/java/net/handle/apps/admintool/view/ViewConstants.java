package net.handle.apps.admintool.view;

public interface ViewConstants {
    public static final int CREATE_HDL_MODE = 1;
    public static final int EDIT_HDL_MODE = 2;
    public static final int VIEW_HDL_MODE = 3;

}
