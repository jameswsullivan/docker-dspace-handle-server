package net.handle.hdllib.trust;

import java.security.PublicKey;
import java.util.List;

public class IssuedSignature {
    public JsonWebSignature jws;
    public PublicKey issuerPublicKey;
    public List<Permission> issuerPermissions;

    public IssuedSignature(JsonWebSignature jws, PublicKey issuerPublicKey, List<Permission> issuerPermissions) {
        this.jws = jws;
        this.issuerPublicKey = issuerPublicKey;
        this.issuerPermissions = issuerPermissions;
    }
}
