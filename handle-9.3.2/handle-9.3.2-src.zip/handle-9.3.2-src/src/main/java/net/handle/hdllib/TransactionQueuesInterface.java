package net.handle.hdllib;

import java.util.List;

public interface TransactionQueuesInterface {

    public List<String> listQueueNames();

    public TransactionQueueInterface getQueue(String name);

    public TransactionQueueInterface getThisServersTransactionQueue();

    public TransactionQueueInterface createNewQueue(String name) throws Exception;

    public TransactionQueueInterface getOrCreateTransactionQueue(String name) throws Exception;

    //    public void addQueueListener(TransactionQueueListener l);
    //
    //    public void removeQueueListener(TransactionQueueListener l);
    
    /** Close any open files or resources in use by the queues. */
    public void shutdown();
}
