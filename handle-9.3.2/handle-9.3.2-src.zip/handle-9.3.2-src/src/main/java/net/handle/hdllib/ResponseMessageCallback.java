package net.handle.hdllib;

/***********************************************************************
 * ResponseMessageCallback is an interface that is used to get
 * continuation messages from multi-message responses.
 ***********************************************************************/

public interface ResponseMessageCallback {

    /*********************************************************************
     * This is called when a message has been received and needs to be
     * handled. <i>message</i> is the message that has been received.
     * Messages are received and processed in order.
     *********************************************************************/
    public void handleResponse(AbstractResponse message) throws HandleException;

}
