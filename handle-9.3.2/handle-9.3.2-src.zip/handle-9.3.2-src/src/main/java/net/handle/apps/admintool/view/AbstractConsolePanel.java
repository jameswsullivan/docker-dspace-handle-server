package net.handle.apps.admintool.view;

import java.awt.LayoutManager;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

import javax.swing.JPanel;

public abstract class AbstractConsolePanel extends JPanel {

    public AbstractConsolePanel(LayoutManager layout) {
        super(layout);
    }

    abstract void writeConsoleContents(Writer w) throws IOException;

    abstract void addText(String text);

    abstract void clear();

    abstract OutputStream getOutputStream();

}
