package net.handle.hdllib;

import java.net.InetAddress;

public abstract class AbstractRequestProcessor implements RequestProcessor {

    @Override
    public AbstractResponse processRequest(AbstractRequest req, InetAddress caller) {
        SimpleResponseMessageCallback callback = new SimpleResponseMessageCallback();
        try {
            processRequest(req, caller, callback);
        } catch (HandleException e) {
            return HandleException.toErrorResponse(req, e);
        }
        return callback.getResponse();
    }

}
