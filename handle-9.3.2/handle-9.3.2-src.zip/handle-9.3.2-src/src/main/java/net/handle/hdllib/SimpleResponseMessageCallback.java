package net.handle.hdllib;

public class SimpleResponseMessageCallback implements ResponseMessageCallback {
    private AbstractResponse message;

    @Override
    public void handleResponse(@SuppressWarnings("hiding") AbstractResponse message) throws HandleException {
        this.message = message;
    }

    public AbstractResponse getResponse() {
        return message;
    }
}
