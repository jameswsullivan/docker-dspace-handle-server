package net.handle.hdllib;

/***************************************************************************
 * Request used to unhome prefix on a given handle server.
 * server.  When sending this request, clients should be prepared to
 * authenticate as an administrator.
 ***************************************************************************/

public class UnhomeNaRequest extends AbstractRequest {

    public UnhomeNaRequest(byte[] na, AuthenticationInfo authInfo) {
        super(na, OC_UNHOME_NA, authInfo);
        this.isAdminRequest = true;
    }
}
