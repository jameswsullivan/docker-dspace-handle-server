package net.handle.apps.batch;

import net.handle.hdllib.HandleValue;

public interface HandleRecordFilter {

    public boolean accept(HandleValue[] values);
}
