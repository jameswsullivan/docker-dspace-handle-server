package net.handle.awt;

import java.awt.*;
import java.util.*;

public class TextPanel extends Panel {

    public TextPanel(String text) {
        super(new GridBagLayout());

        StringTokenizer tokenizer = new StringTokenizer(text, "\n");
        int currentRow = 0;
        add(new Label(""), AwtUtil.getConstraints(0, currentRow, 1, 1, 1, 1, true, true));
        while (tokenizer.hasMoreTokens()) {
            add(new Label(tokenizer.nextToken(), Label.LEFT), AwtUtil.getConstraints(1, currentRow++, 0, 0, 1, 1, true, false));
        }
        add(new Label(" "), AwtUtil.getConstraints(2, currentRow++, 1, 1, 1, 1, true, true));

    }

}
