package net.handle.apps.servlet_proxy;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.handle.server.MonitorDaemon;

public class ProxyStatusServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        MonitorDaemon monitorDaemon = (MonitorDaemon) getServletContext().getAttribute(MonitorDaemon.class.getName());
        resp.getWriter().write(monitorDaemon.getStatusString());
    }
}
