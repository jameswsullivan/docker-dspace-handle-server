package net.handle.hdllib;

/***************************************************************************
 * Request used to home prefix on a given handle server.
 * When sending this request, clients should be prepared to
 * authenticate as an administrator.
 ***************************************************************************/

public class HomeNaRequest extends AbstractRequest {

    public HomeNaRequest(byte[] na, AuthenticationInfo authInfo) {
        super(na, OC_HOME_NA, authInfo);
        this.isAdminRequest = true;
    }
}
