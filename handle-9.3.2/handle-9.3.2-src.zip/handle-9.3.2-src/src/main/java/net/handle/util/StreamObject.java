package net.handle.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

/**
 * @deprecated Replaced by net.cnri.util.StreamObject
 */
@Deprecated
public interface StreamObject {
    public boolean isStreamTable();

    public boolean isStreamVector();

    public void readFrom(String str) throws StringEncodingException, IOException;

    public void readFrom(Reader str) throws StringEncodingException, IOException;

    public void readTheRest(Reader str) throws StringEncodingException, IOException;

    public String writeToString();

    public void writeTo(Writer out) throws IOException;
}
