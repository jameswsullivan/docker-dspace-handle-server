package net.handle.server.storage;

import net.cnri.util.StreamTable;
import net.handle.hdllib.*;
import net.handle.server.HandleStorageFactory;

import java.io.File;
import java.util.Enumeration;

public class PriorityHandleStorage implements HandleStorage {

    private HandleStorage priority;
    private HandleStorage secondary;

    public PriorityHandleStorage() { }

    @Override
    public void init(StreamTable config) throws Exception {
        StreamTable priorityConfig = (StreamTable) config.get("priority");
        StreamTable secondaryConfig = (StreamTable) config.get("secondary");
        File serverDir = getServerDir(config);
        this.priority = HandleStorageFactory.getStorage(serverDir, priorityConfig, true);
        this.secondary = HandleStorageFactory.getStorage(serverDir, secondaryConfig, true);
    }

    private File getServerDir(StreamTable config) {
        String serverDir = config.getStr("serverDir", null);
        if (serverDir != null) {
            return new File(serverDir);
        } else {
            return null;
        }
    }

    @Override
    public boolean haveNA(byte[] authHandle) throws HandleException {
        boolean hasNa = priority.haveNA(authHandle);
        if (!hasNa) {
            hasNa = secondary.haveNA(authHandle);
        }
        return hasNa;
    }

    @Override
    public void setHaveNA(byte[] authHandle, boolean flag) throws HandleException {
        priority.setHaveNA(authHandle, flag);
    }

    @Override
    public void createHandle(byte[] handle, HandleValue[] values) throws HandleException {
        priority.createHandle(handle, values);
    }

    @Override
    public boolean deleteHandle(byte[] handle) throws HandleException {
        return priority.deleteHandle(handle);
    }

    @Override
    public byte[][] getRawHandleValues(byte[] handle, int[] indexList, byte[][] typeList) throws HandleException {
        byte[][] result = priority.getRawHandleValues(handle, indexList, typeList);
        if (result == null) {
            result = secondary.getRawHandleValues(handle, indexList, typeList);
        }
        return result;
    }

    private boolean handleExistsInSecondary(byte[] handle) throws HandleException {
        byte[][] result = secondary.getRawHandleValues(handle, null, null);
        return result != null;
    }

    private boolean handleExistsInPriority(byte[] handle) throws HandleException {
        byte[][] result = priority.getRawHandleValues(handle, null, null);
        return result != null;
    }

    @Override
    public void updateValue(byte[] handle, HandleValue[] values) throws HandleException {
        if (handleExistsInSecondary(handle) && !handleExistsInPriority(handle)) {
            createHandle(handle, values);
        } else {
            priority.updateValue(handle, values);
        }
    }

    @Override
    public void scanHandles(ScanCallback callback) throws HandleException {
        priority.scanHandles(callback);
    }

    @Override
    public void scanNAs(ScanCallback callback) throws HandleException {
        priority.scanNAs(callback);
    }

    @Override
    public Enumeration<byte[]> getHandlesForNA(byte[] naHdl) throws HandleException {
        return priority.getHandlesForNA(naHdl);
    }

    @Override
    public void deleteAllRecords() throws HandleException {
        priority.deleteAllRecords();
    }

    @Override
    public void checkpointDatabase() throws HandleException {
        priority.checkpointDatabase();
    }

    @Override
    public void shutdown() {
        priority.shutdown();
    }
}
