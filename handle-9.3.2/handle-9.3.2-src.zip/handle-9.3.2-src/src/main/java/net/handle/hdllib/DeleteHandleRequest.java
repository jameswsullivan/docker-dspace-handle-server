package net.handle.hdllib;

/******************************************************************************
 * Request used to delete an existing handle.
 ******************************************************************************/

public class DeleteHandleRequest extends AbstractRequest {

    public DeleteHandleRequest(byte handle[], AuthenticationInfo authInfo) {
        super(handle, AbstractMessage.OC_DELETE_HANDLE, authInfo);
        this.isAdminRequest = true;
    }

}
