package net.handle.hdllib;

/***********************************************************************
 * Interface for the transaction queue that is used as a callback from
 * messages like DumpHandlesRequest.
 ***********************************************************************/
public interface TransactionQueueInterface {

    public long getLastTxnId();

    public void addQueueListener(TransactionQueueListener l);

    public void removeQueueListener(TransactionQueueListener l);

    /** Log the specified transaction to the current queue or throw an exception
     * if there is an error or if this is a read-only queue.
     */
    public void addTransaction(long txnId, byte handle[], HandleValue[] values, byte action, long date) throws Exception;

    public void addTransaction(Transaction txn) throws Exception;

    public TransactionScannerInterface getScanner(long lastTxnId) throws Exception;

    public long getFirstDate();

    /** Close any open files or resources in use by the queue. */
    public void shutdown();

    public void deleteUntilDate(long date);
}
