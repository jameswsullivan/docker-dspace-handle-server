package net.handle.util;

/**
 * @deprecated Replaced by net.cnri.util.DeepClone
 */
@Deprecated
public interface DeepClone extends net.cnri.util.DeepClone {
}
