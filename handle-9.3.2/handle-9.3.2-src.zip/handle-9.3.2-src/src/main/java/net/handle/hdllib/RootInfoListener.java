package net.handle.hdllib;

public interface RootInfoListener {

    /** This is called when it is determined that the root info
      for a particular configuration is out of date.  This lets
      an application update it's root information in whatever way
      is appropriate.  If no RootInfoListeners are defined for a
      configuration, then the ~/.handle/root_info file is updated
      with the results of a certified query for the 0.na/0.na handle. */
    public void rootInfoOutOfDate(Configuration configuration);

}
