package net.handle.apps.tools;


import net.cnri.util.StreamTable;
import net.handle.hdllib.HandleStorage;
import net.handle.server.HandleStorageFactory;

import java.io.File;

public class StorageMigrationTool {

    public static void main(String[] args) throws Exception {
        if (args == null || args.length < 2) {
            System.out.println("This tool transfer storage contents form one server to another.");
            System.out.println("It can transfer between different types of storage (ex: BDBJE to SQL)");
            System.out.println("Usage: hdl-migrate-storage <from-server-directory> <to-server-directory>");
            return;
        }
        File fromServerDir = new File(args[0]);
        StreamTable fromServerInfo = new StreamTable();
        fromServerInfo.readFromFile(new File(fromServerDir, "config.dct"));
        fromServerInfo = (StreamTable) fromServerInfo.get("server_config");
        HandleStorage fromStorage = HandleStorageFactory.getStorage(fromServerDir, fromServerInfo, true, true);

        File toServerDir = new File(args[1]);
        StreamTable toServerInfo = new StreamTable();
        toServerInfo.readFromFile(new File(toServerDir, "config.dct"));
        toServerInfo = (StreamTable) toServerInfo.get("server_config");
        HandleStorage toStorage = HandleStorageFactory.getStorage(toServerDir, toServerInfo, true, false);

        StorageMigrator storageMigrator = new StorageMigrator(fromStorage, toStorage);
        System.out.println("Starting migration.");
        storageMigrator.migrate();
        fromStorage.shutdown();
        toStorage.shutdown();
        System.out.println("\nmigration complete");
    }
}
