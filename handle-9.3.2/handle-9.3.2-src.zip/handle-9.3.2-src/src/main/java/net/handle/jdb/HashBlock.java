package net.handle.jdb;

class HashBlock extends Block {
    long nextRecord = 0;
}
