package net.handle.hdllib;

import java.net.InetAddress;

public interface RequestProcessor {
    AbstractResponse processRequest(AbstractRequest req, InetAddress caller) throws HandleException;

    void processRequest(AbstractRequest req, InetAddress caller, ResponseMessageCallback callback) throws HandleException;
}
