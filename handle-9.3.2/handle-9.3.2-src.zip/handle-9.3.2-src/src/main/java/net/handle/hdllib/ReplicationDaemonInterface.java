package net.handle.hdllib;

import java.util.Iterator;

import net.cnri.util.StreamTable;

public interface ReplicationDaemonInterface {

    StreamTable replicationStatus() throws HandleException;

    void pauseReplication();

    void unpauseReplication();

    Iterator<byte[]> handleIterator() throws HandleException;

    Iterator<byte[]> naIterator() throws HandleException;

    Iterator<byte[]> handleIteratorFrom(byte[] startingPoint, boolean inclusive) throws HandleException;

    Iterator<byte[]> naIteratorFrom(byte[] startingPoint, boolean inclusive) throws HandleException;

    public void addQueueListener(TransactionQueueListener l);

    public void removeQueueListener(TransactionQueueListener l);

}
