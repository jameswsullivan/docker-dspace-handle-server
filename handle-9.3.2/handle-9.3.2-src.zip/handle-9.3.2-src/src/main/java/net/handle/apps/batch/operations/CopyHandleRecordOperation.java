package net.handle.apps.batch.operations;

import net.handle.hdllib.AbstractResponse;
import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.SiteInfo;
import net.handle.apps.batch.HandleRecordOperationInterface;
import net.handle.apps.batch.BatchUtil;

public class CopyHandleRecordOperation implements HandleRecordOperationInterface {

    public SiteInfo destinationSite;

    public CopyHandleRecordOperation(SiteInfo destinationSite) {
        this.destinationSite = destinationSite;
    }

    @Override
    public void process(String handle, HandleValue[] values, HandleResolver resolver, AuthenticationInfo authInfo, SiteInfo site) throws HandleException {
        AbstractResponse response = BatchUtil.createHandleRecord(handle, values, resolver, authInfo, destinationSite);
        BatchUtil.throwIfNotSuccess(response);
    }

}
