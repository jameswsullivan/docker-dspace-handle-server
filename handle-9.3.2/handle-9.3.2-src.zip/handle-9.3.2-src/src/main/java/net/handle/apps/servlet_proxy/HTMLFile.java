package net.handle.apps.servlet_proxy;

import java.util.Map;

import net.cnri.util.Template;
import net.cnri.util.TemplateException;
import java.io.*;

import javax.servlet.ServletContext;

public class HTMLFile {
    private final ServletContext context;

    private final String fileName, dir;
    private final File file;
    private final boolean isResource; // whether to use getResource() or normal File io
    private final boolean isServletResource;

    private String page;
    private volatile long lastModified;

    public HTMLFile(String dir, String fileName, ServletContext context) throws IOException {
        this.context = context;
        this.fileName = fileName;
        if (dir.startsWith("servlet:")) {
            isServletResource = true;
            isResource = false;
            this.dir = dir.substring(8);
            file = null;
        } else if (dir.startsWith("res:")) {
            isServletResource = false;
            isResource = true;
            this.dir = dir.substring(4);
            file = null;
        } else {
            isServletResource = false;
            isResource = false;
            File maybeAbsoluteFile = new File(fileName);
            if (maybeAbsoluteFile.isAbsolute()) {
                this.dir = "";
                file = maybeAbsoluteFile;
            } else {
                this.dir = dir;
                file = new File(new File(dir), fileName);
            }
        }
        loadFile();
    }

    private String getPath() {
        return dir + "/" + fileName;
    }

    private void loadFile() throws IOException {
        InputStream in;
        if (isServletResource) {
            in = context.getResourceAsStream(getPath());
        } else if (isResource) {
            in = getClass().getResourceAsStream(getPath());
        } else {
            lastModified = file.lastModified();
            System.err.println("loading file: " + file.getCanonicalPath());
            in = new FileInputStream(file);
        }
        char b[] = new char[1024];
        int len;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            StringBuffer sb = new StringBuffer();
            while (true) {
                len = reader.read(b);
                if (len == -1) break;
                sb.append(b, 0, len);
            }
            page = sb.toString();
        }
    }

    public void output(OutputStream out, Map<String, String> dictParam) throws IOException {
        if (!isResource && !isServletResource && lastModified != file.lastModified()) {
            synchronized (this) {
                if (!isResource && !isServletResource && lastModified != file.lastModified()) {
                    // reload
                    System.err.println("Reloading " + fileName);
                    loadFile();
                }
            }
        }
        try {
            out.write(Template.subDictIntoString(page, dictParam).getBytes("UTF-8"));
        } catch (TemplateException e) {
            throw new IOException("Error templatizing page.", e);
        }
    }
}
