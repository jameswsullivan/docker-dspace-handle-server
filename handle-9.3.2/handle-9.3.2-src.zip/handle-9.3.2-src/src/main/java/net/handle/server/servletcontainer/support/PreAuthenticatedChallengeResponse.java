package net.handle.server.servletcontainer.support;

import net.handle.hdllib.AbstractMessage;
import net.handle.hdllib.ChallengeResponse;

public class PreAuthenticatedChallengeResponse extends ChallengeResponse {
    public PreAuthenticatedChallengeResponse() {
        super(AbstractMessage.OC_RESERVED, null);
    }
}
