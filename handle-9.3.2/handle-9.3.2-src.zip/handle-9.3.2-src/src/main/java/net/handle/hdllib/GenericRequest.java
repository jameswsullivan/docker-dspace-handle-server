package net.handle.hdllib;

public class GenericRequest extends AbstractRequest {
    public GenericRequest(byte handle[], int opCode, AuthenticationInfo authInfo) {
        super(handle, opCode, authInfo);
    }
}
