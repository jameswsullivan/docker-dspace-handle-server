package net.handle.hdllib;

/*********************************************************************
 * Callback for objects that want to be able to scan all of the handles
 * in a HandleStorage instance.
 *********************************************************************/

public interface ScanCallback {
    /*********************************************************************
     * process the specified handle (sent in utf8 format)
     *********************************************************************/
    public void scanHandle(byte handle[]) throws HandleException;
}
