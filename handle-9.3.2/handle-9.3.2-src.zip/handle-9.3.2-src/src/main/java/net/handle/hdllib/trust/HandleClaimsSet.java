package net.handle.hdllib.trust;

import java.security.PublicKey;
import java.util.List;

public class HandleClaimsSet extends JwtClaimsSet {
    public List<Permission> perms;
    public DigestedHandleValues digests;
    public List<String> chain; //first element authorizes the issuer of this claims set. Second element authorizes the issuer of that authorization...
    public PublicKey publicKey;
    public String content; //Optional string to sign.
}
