package net.handle.hdllib;

/** Generic response without any fields or parameters
 */

public class GenericResponse extends AbstractResponse {

    public GenericResponse() {
        super();
    }

    public GenericResponse(int opCode, int responseCode) {
        super(opCode, responseCode);
    }

    public GenericResponse(AbstractRequest req, int responseCode) throws HandleException {
        super(req, responseCode);
    }

}
