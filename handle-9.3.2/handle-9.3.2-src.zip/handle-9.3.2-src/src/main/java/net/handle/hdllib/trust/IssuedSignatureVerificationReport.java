package net.handle.hdllib.trust;

public class IssuedSignatureVerificationReport extends SignatureVerificationReport {

    // permission granted
    public Boolean authorized;

    public boolean canTrustAndAuthorized() {
        return canTrust() && authorized != null && authorized;
    }
}
