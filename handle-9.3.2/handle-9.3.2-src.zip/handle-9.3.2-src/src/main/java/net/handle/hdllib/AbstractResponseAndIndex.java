package net.handle.hdllib;

public class AbstractResponseAndIndex {
    final AbstractResponse response;
    final int index;

    public AbstractResponseAndIndex(int index, AbstractResponse response) {
        this.response = response;
        this.index = index;
    }

    public AbstractResponse getResponse() {
        return response;
    }

    public int getIndex() {
        return index;
    }
}
