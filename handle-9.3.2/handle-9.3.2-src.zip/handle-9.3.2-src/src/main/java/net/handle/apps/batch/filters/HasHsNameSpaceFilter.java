package net.handle.apps.batch.filters;

import java.util.List;

import net.handle.hdllib.HandleValue;
import net.handle.apps.batch.HandleRecordFilter;
import net.handle.apps.batch.BatchUtil;

public class HasHsNameSpaceFilter implements HandleRecordFilter {

    @Override
    public boolean accept(HandleValue[] values) {
        List<HandleValue> nameSpaceValues = BatchUtil.getValuesOfType(values, "HS_NAMESPACE");
        if (nameSpaceValues.size() != 0) {
            return true;
        }
        return false;
    }

}
