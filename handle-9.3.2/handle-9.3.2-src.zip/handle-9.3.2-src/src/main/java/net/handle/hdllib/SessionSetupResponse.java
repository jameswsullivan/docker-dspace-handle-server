package net.handle.hdllib;

public class SessionSetupResponse extends AbstractResponse {

    //member variable
    public int keyExchangeMode; // KEY_EXCHANGE_* from Common.java
    // one of: encrypted session key, exchange pubkey, or DH params
    public byte data[] = null;

    public SessionSetupResponse(int mode, byte data[]) {
        super(OC_SESSION_SETUP, AbstractMessage.RC_SUCCESS);
        this.data = data;
        this.keyExchangeMode = mode;
    }

    public SessionSetupResponse(SessionSetupRequest req, byte data[]) throws HandleException {
        super(req, AbstractMessage.RC_SUCCESS);
        this.data = data;
        this.keyExchangeMode = req.keyExchangeMode;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(super.toString());
        sb.append(' ');

        return sb.toString();
    }
}
