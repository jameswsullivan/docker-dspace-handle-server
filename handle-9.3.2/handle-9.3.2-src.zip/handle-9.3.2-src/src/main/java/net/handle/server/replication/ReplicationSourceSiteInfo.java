package net.handle.server.replication;

import net.handle.hdllib.SiteInfo;

public class ReplicationSourceSiteInfo {
    private SiteInfo site;
    private String name;

    public ReplicationSourceSiteInfo(SiteInfo site, String name) {
        this.site = site;
        this.name = name;
    }

    public SiteInfo getSite() {
        return site;
    }

    public String getName() {
        return name;
    }

    public void setSite(SiteInfo site) {
        this.site = site;
    }

    public void setName(String name) {
        this.name = name;
    }
}
