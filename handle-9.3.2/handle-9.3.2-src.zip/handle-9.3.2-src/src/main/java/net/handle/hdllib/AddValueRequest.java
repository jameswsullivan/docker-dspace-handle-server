package net.handle.hdllib;

/******************************************************************************
 * Request used to add a value to an existing handle.  Holds the handle
 * and the value to be added.
 ******************************************************************************/

public class AddValueRequest extends AbstractRequest {

    public HandleValue values[];

    public AddValueRequest(byte handle[], HandleValue value, AuthenticationInfo authInfo) {
        this(handle, new HandleValue[] { value }, authInfo);
    }

    public AddValueRequest(byte handle[], HandleValue values[], AuthenticationInfo authInfo) {
        super(handle, AbstractMessage.OC_ADD_VALUE, authInfo);
        this.values = values;
        this.isAdminRequest = true;
    }

    @Override
    public boolean shouldEncrypt() {
        if (!hasEqualOrGreaterVersion(2, 8)) return false;
        if (values == null) return false;
        for (HandleValue value : values) {
            if (!value.publicRead) return true;
        }
        return false;
    }
}
