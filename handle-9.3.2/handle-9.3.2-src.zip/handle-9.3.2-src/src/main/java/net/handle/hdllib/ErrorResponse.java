package net.handle.hdllib;

public class ErrorResponse extends AbstractResponse {

    public byte message[];

    public ErrorResponse(byte message[]) {
        this.message = message;
    }

    public ErrorResponse(int opCode, int responseCode, byte message[]) {
        super(opCode, responseCode);
        this.message = message;
    }

    public ErrorResponse(AbstractRequest req, int errorCode, byte message[]) throws HandleException {
        super(req, errorCode);
        this.message = message;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Error(");
        sb.append(responseCode);
        sb.append("): ");
        sb.append(AbstractMessage.getResponseCodeMessage(responseCode));
        if (message != null && message.length > 0) {
            sb.append(": ");
            sb.append(Util.decodeString(message));
        }
        return sb.toString();
    }
}
