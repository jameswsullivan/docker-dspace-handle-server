package net.handle.apps.admintool.view;

public class RemoteSignerInfo {

    public String issuer;
    public String baseUri;
    public String username;
    public String password;
    public String privateKeyId;
    public String privateKeyPassphrase;

    public RemoteSignerInfo(String signerHandleId, String baseUri, String username, String password, String privateKeyId, String privateKeyPassphrase) {
        this.issuer = signerHandleId;
        this.baseUri = baseUri;
        this.username = username;
        this.password = password;
        this.privateKeyId = privateKeyId;
        this.privateKeyPassphrase = privateKeyPassphrase;
    }
}
