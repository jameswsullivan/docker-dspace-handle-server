package net.handle.hdllib;

/******************************************************************************
 * Request used to remove a value from an existing handle.  Holds the handle
 * and the index of the value to be deleted.
 ******************************************************************************/

public class RemoveValueRequest extends AbstractRequest {

    public int indexes[];

    public RemoveValueRequest(byte handle[], int index, AuthenticationInfo authInfo) {
        this(handle, new int[] { index }, authInfo);
    }

    public RemoveValueRequest(byte handle[], int indexes[], AuthenticationInfo authInfo) {
        super(handle, AbstractMessage.OC_REMOVE_VALUE, authInfo);
        this.indexes = indexes;
        this.isAdminRequest = true;
    }

}
