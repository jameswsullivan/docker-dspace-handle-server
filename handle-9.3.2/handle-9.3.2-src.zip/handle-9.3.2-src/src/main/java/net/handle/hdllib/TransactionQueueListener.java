package net.handle.hdllib;

public interface TransactionQueueListener {

    public void transactionAdded(Transaction txn);

    public void shutdown();

}
