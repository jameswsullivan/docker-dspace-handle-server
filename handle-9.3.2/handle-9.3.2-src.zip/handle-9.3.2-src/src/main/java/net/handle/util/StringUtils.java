package net.handle.util;

/**
 * @deprecated Replaced by net.cnri.util.StringUtils
 */
@Deprecated
public class StringUtils extends net.cnri.util.StringUtils {
}
