package net.handle.server.replication;

import net.handle.hdllib.ReplicationStateInfo;
import net.handle.hdllib.SiteInfo;

public class RedumpErrorMessage {
    public String type = "RedumpErrorMessage";
    public SiteInfo receivingSiteInfo;
    public int receivingServerNumber;
    public SiteInfo sourceSiteInfo;
    public String sourceSiteName;
    public int sourceServerNumber;
    public ReplicationStateInfo replicationStateInfo;
}
