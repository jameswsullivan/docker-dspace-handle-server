package net.handle.apps.admintool.view;

import net.handle.hdllib.*;

public interface HandleValueEditor {

    /**
     * Saves the handle value data in the given HandleValue.  Returns false
     * if there was an error and the operation was canceled.
     */
    public boolean saveValueData(HandleValue value);

    /**
     * Sets the handle value data from the given HandleValue.
     */
    public void loadValueData(HandleValue value);

}
