package net.handle.hdllib;

public interface SiteFilter {
    boolean apply(SiteInfo site);
}
