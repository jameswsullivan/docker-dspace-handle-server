package net.handle.server;
public class Version {
    public static final String version="9.3.1";
}