These jars are automatically used on Handle server startup when it 
is necessary to perform a special upgrade procedure on storage from 
an earlier version.  No manual action need be taken.  After the 
first successful server start, these jars and the "jeUpgradeTool" 
directory can be permanently deleted if desired.
